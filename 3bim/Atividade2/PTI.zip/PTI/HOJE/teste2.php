<?php
require('fpdf/fpdf.php');
$pdf = new FPDF('P','pt','A4');

$pdf->SetTitle('Teste PDF 1');
$pdf->SetAuthor('Marcelo Mussel');
$pdf->SetCreator('php'.phpversion());
$pdf->SetKeywords('php','pdf');
$pdf->SetSubject('Como criar um pdf');

$pdf->AddPage();
//definir a fonte
$pdf->SetFont('Arial','',12);
$pdf->Text(0,12,'x1');
//espaçamento vertical 
$pdf->Ln(20);
$pdf->SetFont('courier','B','16');
$pdf->SetTextColor(50,50,100);
$pdf->SetY(70);
$pdf->SetX(260);
$Titulo = 'Título';
$Titulo = utf8_decode($Titulo);
$pdf->Write(30,$Titulo);
$pdf->Ln(30);
$txt=str_repeat('bla bla blá blá',30);
$txt = utf8_decode($txt);
$pdf->SetTextColor(100,50,50);
$pdf->SetFont('times','B',14);
$pdf->Write(20,$txt);
$pdf->Output();
