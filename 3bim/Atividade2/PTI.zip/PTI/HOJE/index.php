<?php
require('fpdf/fpdf.php');
require_once '../init-cliente.php';

$PDO = db_connect();
$sql = "SELECT nomeCliente FROM clientes ORDER BY nomeCliente ASC";
$stmt= $PDO->prepare($sql);
$stmt->execute();



$pdf = new FPDF('P','pt','A4');

$pdf->SetTitle('Trabalho 2');
$pdf->SetAuthor('Eduardo e Larissa M.');
$pdf->SetCreator('php'.phpversion());
$pdf->SetKeywords('php','pdf');
$pdf->SetSubject('Gerar PDF');

while($cliente = $stmt->fetch(PDO::FETCH_ASSOC)){ 


$pdf->AddPage();
//definir a fonte
$pdf->SetFont('Arial','',12);
//$pdf->Text(0,12,'x1');
//espaçamento vertical 
$pdf->Ln(20);
$pdf->SetFont('Arial','','12');
$pdf->SetTextColor('#ffff');
$pdf->SetX(280);



$Data = 'Varginha, '.date("d/m/Y");
$Data = utf8_decode($Data);
$pdf->Write(50,$Data);
$pdf->Ln(50);
$pdf->SetX(30);


$Titulo = 'Prezado(a) Sr(a) '.$cliente['nomeCliente'];
$Titulo = utf8_decode($Titulo);
$pdf->Write(50,$Titulo);
$pdf->Ln(50);
$pdf->SetX(40);


$Conteudo = 'Neste mês de aniversário, nossa loja está com promoções imperdíveis e selecionadas especialmente para vocẽ.';
$Conteudo = utf8_decode($Conteudo);
$pdf->Write(15,$Conteudo);
$pdf->Ln(15);
$pdf->SetX(40);

$Conteudo = 'Não perca essa oportunidade de realizar bons negocios.';
$Conteudo = utf8_decode($Conteudo);
$pdf->Write(15,$Conteudo);
$pdf->Ln(15);
$pdf->SetX(40);

$Conteudo = 'Faça-nos uma visita.';
$Conteudo = utf8_decode($Conteudo);
$pdf->Write(15,$Conteudo);
$pdf->Ln(15);
$pdf->SetX(30);

$Conteudo = 'Cordialmente,';
$Conteudo = utf8_decode($Conteudo);
$pdf->Write(100,$Conteudo);
$pdf->Ln(100);
$pdf->SetX(250);

$Final = 'Larissa';
$Final = utf8_decode($Final);
$pdf->Write(15,$Final);
$pdf->Ln(15);
$pdf->SetX(220);

$Final = 'Gerente Comercial';
$Final = utf8_decode($Final);
$pdf->Write(15,$Final);
$pdf->Ln(15);

}

//$pdf->SetTextColor(100,50,50);
$pdf->SetFont('times','B',14);
$pdf->Output();
