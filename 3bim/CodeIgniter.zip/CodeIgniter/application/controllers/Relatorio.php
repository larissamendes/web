<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Relatorio extends CI_Controller {

	public function index()
	{
		$this->load->view('pagina_inicial');
	}
	
	public function relatoriopdf(){
		$data['x']=$this->db->get('citacoes')->result();
		$this->load->view('relatoriopdf', $data);
	}
	
	public function cadastro()
	{
		$this->load->helper('form');	
		$this->load->view('cadastro');
	}
	public function adicionar(){
		if( $this->input->post('txt_nome') == null ||
			$this->input->post('txt_titulo') == null || 
			$this->input->post('txt_autores') == null ||
			$this->input->post('txt_citacoes')== null ||
			$this->input->post('txt_ref') == null ||
			$this->input->post('txt_pchave')== null){
			$this->load->view('errocad');
		}else{	
			$info['nomeArquivo']=$this->input->post('txt_nome');
			$info ['titulo']=$this->input->post('txt_titulo');
			$info['autores']=$this->input->post('txt_autores');
			$info ['citacoes']=$this->input->post('txt_citacoes');
			$info['referencias']=$this->input->post('txt_ref');
			$info ['dataCadastro']=$this->input->post('txt_data');
			$info['palavrasChave']=$this->input->post('txt_pchave');
		
			if($this->db->insert('citacoes',$info)){
				redirect(base_url());
			}else{
				echo "Não foi possível gravar a postagem no banco de dados";
			}
		}
	}
}
