<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<title>Cadastro</title>	
</head>
<body>
	<div class="cadastro">
		<h3>Cadastro</h3>
		<?php
			defined('BASEPATH') OR exit('No direct script access allowed');
			echo anchor(base_url(), "Página Inicial");
			echo form_open(base_url('relatorio/adicionar')) .	
			form_label(" Nome do Arquivo :"," txt_nome") . br().
			form_input('txt_nome') . br() .
	
			form_label(" Título :"," txt_titulo") . br().
			form_input('txt_titulo') . br() .
	
			form_label(" Autores :"," txt_autores") . br().
			form_textarea('txt_autores') . br() .
		
			form_label(" Citações :"," txt_citacoes") . br().
			form_textarea('txt_citacoes') . br() .
	
			form_label(" Referências :"," txt_ref") . br().
			form_textarea('txt_ref') . br() .
	
			form_label(" Palavras-Chave :"," txt_pchave") . br().
			form_textarea('txt_pchave') . br() .
	

			form_submit(" btn_enviar", "Enviar Dados") .
			form_close();
		?>
</div>
</body>
</html>

