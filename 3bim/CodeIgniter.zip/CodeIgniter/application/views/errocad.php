<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Erro ao Cadastrar</title>	
</head>
<body>
	<h1>Você não preencheu todos os campos, tente de novo!</h1>
	<?php echo anchor(base_url(), "Página Inicial") . br() . anchor(base_url('relatorio/cadastro'), "Cadastro") ; ?>
</body>
</html>
<?php
?>
