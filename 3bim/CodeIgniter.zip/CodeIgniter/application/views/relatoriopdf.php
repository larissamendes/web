<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require 'assets/fpdf/fpdf.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Relatorio</title>	
</head>
<body>
	<?php
		$pdf = new FPDF('P','pt','A4');
		$pdf->SetFont('Arial','',12);
		$pdf->AddPage();
		foreach($x as $texto) {	
			
			$t = $texto->nomeArquivo;
			$t = utf8_decode($t);
			$pdf->Write(15,$t);
			$pdf->Ln(20);
			
			$t = $texto->titulo;
			$t = utf8_decode($t);
			$pdf->Write(15,$t);
			$pdf->Ln(20);
			
			$t = $texto->autores;
			$t = utf8_decode($t);
			$pdf->Write(15,$t);
			$pdf->Ln(20);
			
			$t = $texto->citacoes;
			$t = utf8_decode($t);
			$pdf->Write(15,$t);
			$pdf->Ln(20);
			
			$t = $texto->referencias;
			$t = utf8_decode($t);
			$pdf->Write(15,$t);
			$pdf->Ln(20);
			
			$t = $texto->dataCadastro;
			$pdf->Write(15,$t);
			$pdf->Ln(20);
			
			$t = $texto->palavrasChave;
			$t = utf8_decode($t);
			$pdf->Write(15,$t);
			$pdf->Ln(20);
			
			$pdf->SetY(70);
			$pdf->SetX(260);
			
		}
		$pdf->Output();	
	?>
</body>
</html>
