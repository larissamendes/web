<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Página Inicial</title>	
	<?php
			echo link_tag('https://fonts.googleapis.com/css?family=Roboto+Condensed');
  			echo link_tag('assets/css/estilizacao.css');
  		?>
</head>
<body>
	<div class="menu">
<h2 style="color:white">Menu</h2>
	<?php
	echo anchor(base_url(), "Página Inicial") .br()
	.anchor(base_url("relatorio/cadastro"),"Cadastrar Nova Referência").br()
	.anchor(base_url("relatorio/relatoriopdf"),"Listagem das Referências Cadastradas").br()
	.anchor(base_url(),"Consulta Referências") ;
?>
</div>
</body>
</html>
